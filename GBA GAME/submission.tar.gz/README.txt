Game created by: Sharanya Pillalamarri
Game name: Find your home!
Gameplay: In this game you play as a dog. You need to find your way to the house on the screen. Initially you are
            presented with a welcome screen. In order to begin the game you need to press the START button (ENTER key).
            Then you enter the game screen where the dog and its house are placed in different locations. You can use
            the UP, DOWN, LEFT AND RIGHT arrow keys in order to move the dog towards the house. Once the dog collides
            with the house, you win the game! Throughout the game, there is text indicating how many steps away the dog
            is from the house. At any time in the game, you can press the SELECT button (BACKSPACE key) to exit the game.
            As before, you need to click the START button (ENTER key) in order to restart the game!
            Now it is time to find the corgi its home!!!

Images used:

the dog: https://www.clipartmax.com/download/m2i8G6b1G6A0Z5b1_tumblr-pixel-corgi-dog-dogs-swim-animated-corgi-gif/
the house: https://www.cleanpng.com/png-pixel-art-video-games-architecture-7165141/
the welcome screen image: http://rolfpreuss.com/portfolio-digital-art/hawaii-ii/
the win/ending screen image: https://weheartit.com/entry/180912176