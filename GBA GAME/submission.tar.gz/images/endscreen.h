/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 endscreen endscreen.png 
 * Time-stamp: Wednesday 04/07/2021, 17:43:35
 * 
 * Image Information
 * -----------------
 * endscreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENDSCREEN_H
#define ENDSCREEN_H

extern const unsigned short endscreen[38400];
#define ENDSCREEN_SIZE 76800
#define ENDSCREEN_LENGTH 38400
#define ENDSCREEN_WIDTH 240
#define ENDSCREEN_HEIGHT 160

#endif

