/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 gbachar gbachar.png 
 * Time-stamp: Wednesday 04/07/2021, 20:30:29
 * 
 * Image Information
 * -----------------
 * gbachar.png 21@21
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GBACHAR_H
#define GBACHAR_H

extern const unsigned short gbachar[441];
#define GBACHAR_SIZE 882
#define GBACHAR_LENGTH 441
#define GBACHAR_WIDTH 21
#define GBACHAR_HEIGHT 21

#endif

