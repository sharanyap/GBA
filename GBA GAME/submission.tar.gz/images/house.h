/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 house house.png 
 * Time-stamp: Tuesday 04/06/2021, 18:54:58
 * 
 * Image Information
 * -----------------
 * house.png 44@44
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HOUSE_H
#define HOUSE_H

extern const unsigned short house[1936];
#define HOUSE_SIZE 3872
#define HOUSE_LENGTH 1936
#define HOUSE_WIDTH 44
#define HOUSE_HEIGHT 44

#endif

