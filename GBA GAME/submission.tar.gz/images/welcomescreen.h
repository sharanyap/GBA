/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 welcomescreen welcomescreen.png 
 * Time-stamp: Wednesday 04/07/2021, 17:43:10
 * 
 * Image Information
 * -----------------
 * welcomescreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WELCOMESCREEN_H
#define WELCOMESCREEN_H

extern const unsigned short welcomescreen[38400];
#define WELCOMESCREEN_SIZE 76800
#define WELCOMESCREEN_LENGTH 38400
#define WELCOMESCREEN_WIDTH 240
#define WELCOMESCREEN_HEIGHT 160

#endif

